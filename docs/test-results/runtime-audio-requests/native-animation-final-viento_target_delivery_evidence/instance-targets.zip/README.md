# Viento backend project delivery / 后端工程交付 / バックエンドプロジェクト配布

Backend: org.viento.godot4
Project kind: godot-project
Entry: project/project.godot
Assembly / 组装 / 組立: 12345678-1234-4234-8234-123456789abc
Entry scene / 启动场景 / 起動シーン: dddddddd-dddd-4ddd-8ddd-dddddddddddd
Scenes / 场景 / シーン: 2
Inventory / 清单 / 一覧: project/assembly.json
Build: e35ef427-6147-46ae-b755-4f0d58607d5d
Tool: 4.7.2.stable.viento_audiofix1_ed1daf0bf
Tool SHA-256: d0214fafa4af018589761b772f38be02b421cd021ed69c45c1d7a4bcd2acbb04
Tool platform: linux/x64

中文
这是由已保存作者输入生成的派生工程，不是独立可执行程序。解压后从上述入口打开；Godot 工程需要兼容的 Godot，Bevy 场景数据需要对应的可信运行程序，不是 Cargo 源工程。工具程序未包含。包内仅有登记的生成文件、素材副本和构建所需脚本副本。原始作者输入、完整快照、运行日志、缓存和本机配置未打包；清单中的来源与证据仅为审计引用。需要继续作者编辑或完整迁移，请另行使用 .viento.zip 源项目包。修改派生工程不会回写作者工程。校验包内容不等于授予运行权限，运行脚本前应审阅来源。

English
This is a derived project generated from saved author inputs, not a standalone executable. After extraction, open the entry above. Godot projects require compatible Godot; Bevy scene data requires the corresponding trusted runtime and is not a Cargo source project. No tool executable is bundled. Only registered generated files, resource copies and required script copies are included. Original author inputs, the complete snapshot, runtime logs, caches and local configuration are excluded; provenance and evidence entries are audit references only. Use a separate .viento.zip source project package for author editing or full migration. Changes to this derived project do not update author inputs. Content verification grants no execution permission; review script origins before running.

日本語
これは保存済みの作者データから生成した派生プロジェクトであり、単独実行形式ではありません。展開後は上記の入口を開いてください。Godot プロジェクトには互換性のある Godot が必要です。Bevy のシーンデータには対応する信頼済みランタイムが必要で、Cargo ソースプロジェクトではありません。実行ツールは同梱しません。登録された生成ファイル、素材のコピー、必要なスクリプトのコピーのみを含みます。作者の元データ、完全なスナップショット、実行ログ、キャッシュ、ローカル設定は含みません。来歴と証拠の項目は監査用の参照です。作者データの編集や完全な移行には別途 .viento.zip を使用してください。派生プロジェクトの変更は作者データへ反映されません。内容の検証は実行権限を付与しません。スクリプトは出所を確認してから実行してください。
