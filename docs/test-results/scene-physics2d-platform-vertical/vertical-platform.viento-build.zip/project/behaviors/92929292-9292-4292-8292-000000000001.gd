extends Node
var ticks := -1
func _ready() -> void:
	var port = get_meta("viento_platform_events")
	port.origin_reached.connect(endpoint.bind("origin"))
	port.destination_reached.connect(endpoint.bind("destination"))
func endpoint(name: String) -> void:
	print("VERTICAL_ENDPOINT:" + JSON.stringify({"name":name,"step":get_parent().get_parent().physics_observation_step}))
func _physics_process(_delta: float) -> void:
	var scene = get_parent().get_parent()
	var tick: int = scene.physics_observation_step
	if ticks == tick:
		return
	ticks = tick
	pass
	var rows := []
	for actor in scene.actors:
		if actor["instanceId"] in ["bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbb1","79797979-7979-4979-8979-000000000003","79797979-7979-4979-8979-000000000001","83838383-8383-4838-8838-000000000001"]:
			rows.append({"id":actor["instanceId"],"position":[actor["node"].position.x,actor["node"].position.y],"grounded":scene.character_motion_grounded.get(actor["instanceId"],false) if scene.get("character_motion_grounded") is Dictionary else false})
	print("VERTICAL_PROBE:" + JSON.stringify({"step":ticks,"actors":rows,"phase":scene.platform_motion.platforms["79797979-7979-4979-8979-000000000001"]["phase"]}))
