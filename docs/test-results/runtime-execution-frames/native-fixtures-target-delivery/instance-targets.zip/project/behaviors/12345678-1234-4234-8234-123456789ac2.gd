extends Node
func _ready() -> void:
	call_deferred("_probe")
func _probe() -> void:
	var host = get_tree().root.get_node("VientoProject")
	host.set_process(false)
	host.flush_requests()
	var port = get_meta("viento_project")
	port.write_state("ready", true)
	port.publish_event("action", true)
	host.flush_requests()
	host.elapsed_seconds += 0.5
	host.total_seconds += 0.5
	host.current.project_step(0.5)
	host.flush_requests()
	print("DELIVERY_LANES:" + JSON.stringify(host.current.project_animation_lanes))
	host.finish_project()
