extends "res://scenes/12345678-1234-4234-8234-123456789abd/audio-runtime.gd"

const PROJECT_AUDIO_TRACKS = {"77777777-7777-4777-8777-000000000001":"99999999-9999-4999-8999-999999999999","77777777-7777-4777-8777-000000000002":"99999999-9999-4999-8999-999999999999"}

var project_host
var project_visit := 0
var project_open := true

func _ready() -> void:
	super._ready()
	# The project owns both deterministic smoke steps and live actor/audio time.
	# Author behavior children retain their normal single Godot process callback.
	smoke = true
	set_process(false)

func run_smoke() -> void:
	pass

func project_behavior_port(binding: Dictionary, instance: Node) -> RefCounted:
	return project_host.make_port(project_visit, binding, instance)

func emit(event: String, data: Dictionary = {}) -> void:
	if not project_open or event == "finished":
		return
	if event == "diagnostic":
		audio_failed = true
	data["protocol"] = 2
	data["event"] = event
	project_host.scene_event(project_visit, "runtime", data)

func audio_emit(event: String, data: Dictionary = {}) -> void:
	if not project_open:
		return
	data["protocol"] = 1
	data["event"] = event
	project_host.scene_event(project_visit, "audio", data)

func project_step(delta: float) -> void:
	if project_open:
		super._process(delta)

func project_close(silent: bool = false) -> void:
	process_mode = Node.PROCESS_MODE_DISABLED
	pass
	if silent:
		project_open = false
	audio_shutdown()
	pass
	project_open = false

# Generated private bridge: author ports receive only a boolean acceptance.
func project_audio_resource(track_id: String) -> String:
	return PROJECT_AUDIO_TRACKS.get(track_id, "")

func project_audio_execute(track_id: String, action: String) -> bool:
	if not project_open or not audio_started or audio_failed or audio_finished or not audio_players.has(track_id):
		return false
	var player = audio_players[track_id]
	if not is_instance_valid(player) or not player is AudioStreamPlayer:
		return false
	if action == "play":
		player.play(0.0)
	elif action == "stop":
		player.stop()
	else:
		return false
	return true

func project_audio_time() -> float:
	return audio_time
