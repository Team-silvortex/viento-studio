extends Node
var project
func _ready() -> void:
	project = get_meta("viento_project")
	project.write_state("score", 0)
	project.write_state("truth", false)
	project.write_state("health", 50)
func update_values() -> void:
	project.write_state("score", 1.2345)
	project.write_state("truth", true)
	project.write_state("health", 75)
