extends Node
var project
func _ready() -> void:
	project = get_meta("viento_project")
func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("game_complete", false):
		# The filter ignores the first two payloads. Both matching publications
		# are delivered in the same FIFO batch; only the first requests a switch.
		project.publish_event("game.complete", false)
		project.publish_event("game.complete", "lose")
		project.publish_event("game.complete", "win")
		project.publish_event("game.complete", "win")
