extends Node
var project
var ticks := 0
var last_frame := -1
var audits := 0
var subscription := 0
func _ready() -> void:
	project = get_meta("viento_project")
	subscription = project.subscribe_event("game.audit", _audit)
	assert(subscription > 0, "game audit subscription was refused")
func _audit(_value) -> bool:
	audits += 1
	return true
func _process(_delta: float) -> void:
	var frame := Engine.get_process_frames()
	assert(frame != last_frame, "duplicate behavior processing in one frame")
	last_frame = frame
	ticks += 1
func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("game_mutate", false):
		assert(project.write_state("level", 4))
		assert(project.write_state("score", 75))
		assert(project.write_state("health", 12))
		assert(project.write_state("key_found", true))
		assert(project.write_state("progress", "checkpoint-7"))
		assert(project.publish_event("game.audit", true))
	if event.is_action_pressed("game_fail", false):
		assert(project.publish_event("game.failed", "lose"))
		assert(project.publish_event("game.failed", "lose"))
func _exit_tree() -> void:
	if project != null and subscription > 0:
		project.unsubscribe_event(subscription)
