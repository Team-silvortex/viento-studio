extends Node
func _ready() -> void:
	var project = get_meta("viento_project")
	if project.read_state("progress") == null:
		project.write_state("progress", "menu-seed")
