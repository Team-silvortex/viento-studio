extends "res://scenes/dddddddd-dddd-4ddd-8ddd-dddddddddddd/animation-runtime.gd"

const PROJECT_AUDIO_TRACKS = {"77777777-7777-4777-8777-000000000001":"99999999-9999-4999-8999-999999999999","77777777-7777-4777-8777-000000000002":"99999999-9999-4999-8999-999999999999"}

var project_host
var project_visit := 0
var project_open := true

func _ready() -> void:
	super._ready()
	# The project owns both deterministic smoke steps and live actor/audio time.
	# Author behavior children retain their normal single Godot process callback.
	smoke = true
	set_process(false)

func run_smoke() -> void:
	pass

func project_behavior_port(binding: Dictionary, instance: Node) -> RefCounted:
	return project_host.make_port(project_visit, binding, instance)

func emit(event: String, data: Dictionary = {}) -> void:
	if not project_open or event == "finished":
		return
	if event == "diagnostic":
		behavior_failed = true
		audio_failed = true
		animation_failed = true
	data["protocol"] = 3
	data["event"] = event
	project_host.scene_event(project_visit, "runtime", data)

func audio_emit(event: String, data: Dictionary = {}) -> void:
	if not project_open:
		return
	data["protocol"] = 1
	data["event"] = event
	project_host.scene_event(project_visit, "audio", data)

func project_step(delta: float) -> void:
	if project_open:
		super._process(delta)

func project_close(silent: bool = false) -> void:
	process_mode = Node.PROCESS_MODE_DISABLED
	behavior_finished = true
	if silent:
		project_open = false
	audio_shutdown()
	animation_shutdown()
	project_open = false

# Generated private bridge: author ports receive only a boolean acceptance.
func project_audio_resource(track_id: String) -> String:
	return PROJECT_AUDIO_TRACKS.get(track_id, "")

func project_audio_execute(track_id: String, action: String) -> bool:
	if not project_open or not audio_started or audio_failed or audio_finished or not audio_players.has(track_id):
		return false
	var player = audio_players[track_id]
	if not is_instance_valid(player) or not player is AudioStreamPlayer:
		return false
	if action == "play":
		player.play(0.0)
	elif action == "stop":
		player.stop()
	else:
		return false
	return true

func project_audio_time() -> float:
	return audio_time

func project_behavior_instance(binding: Dictionary, script: Script):
	return project_host.make_behavior_instance(project_visit, binding, script)

# Range transport retains a local position. Only visual sampling adds the range
# start; the document loop is never applied a second time to that sample time.
const PROJECT_ANIMATION_SCENE = "dddddddd-dddd-4ddd-8ddd-dddddddddddd"
const PROJECT_ANIMATION_DURATION_BYTES = [0,0,0,0,0,0,240,63]
const PROJECT_ANIMATION_CLIPS = {"59595959-5959-4595-8595-000000000001":{"startBytes":[0,0,0,0,0,0,208,63],"endBytes":[0,0,0,0,0,0,232,63],"loop":true},"59595959-5959-4595-8595-000000000002":{"startBytes":[0,0,0,0,0,0,224,63],"endBytes":[205,204,204,204,204,204,228,63],"loop":false}}
var project_animation_completion_sent := false
var project_animation_phase := "playing"
var project_animation_clock := 0.0
var project_animation_clip = null
var project_animation_position := 0.0
var project_animation_anchor_clock := 0.0
var project_animation_anchor_position := 0.0
var project_animation_anchor_phase := "playing"

func project_animation_declared() -> bool:
	return true

func project_animation_duration() -> float:
	return PackedByteArray(PROJECT_ANIMATION_DURATION_BYTES).decode_double(0)

func project_animation_clip_known(clip_id) -> bool:
	return clip_id == null or typeof(clip_id) == TYPE_STRING and PROJECT_ANIMATION_CLIPS.has(clip_id)

func project_animation_range() -> Dictionary:
	if project_animation_clip == null:
		return {"start": 0.0, "end": animation_duration, "duration": animation_duration, "loop": animation_loop}
	var clip: Dictionary = PROJECT_ANIMATION_CLIPS[project_animation_clip]
	var start: float = PackedByteArray(clip["startBytes"]).decode_double(0)
	var end: float = PackedByteArray(clip["endBytes"]).decode_double(0)
	return {"start": start, "end": end, "duration": end - start, "loop": clip["loop"]}

func project_animation_command_valid(command: Dictionary) -> bool:
	return command["action"] != "seek" or float(command["positionSeconds"]) <= project_animation_range()["duration"]

func project_animation_sample() -> void:
	var selected := project_animation_range()
	animation_time = selected["end"] if not selected["loop"] and project_animation_position == selected["duration"] else selected["start"] + project_animation_position
	animation_apply()

func animation_advance(_delta: float) -> void:
	if not project_open or not animation_started or animation_failed or animation_finished:
		return
	var seconds: float = project_host.elapsed_seconds
	var elapsed: float = seconds - project_animation_anchor_clock
	var selected := project_animation_range()
	var duration: float = selected["duration"]
	project_animation_clock = seconds
	project_animation_phase = project_animation_anchor_phase
	project_animation_position = project_animation_anchor_position
	if project_animation_phase == "playing":
		if selected["loop"]:
			project_animation_position = fmod(project_animation_anchor_position + fmod(elapsed, duration), duration)
		elif elapsed >= duration - project_animation_anchor_position:
			project_animation_position = duration
		else:
			# Match the Rust remaining-time comparison before adding, including
			# the distinct rounding boundaries of subtraction and addition.
			project_animation_position = minf(project_animation_anchor_position + elapsed, duration)
		if not selected["loop"] and project_animation_position == duration:
			project_animation_phase = "finished"
		project_animation_sample()
		if not animation_failed and not project_host.failed and project_animation_phase == "finished" and not project_animation_completion_sent:
			project_animation_completion_sent = true
			project_host.animation_completions.complete(project_visit, project_animation_snapshot())

func project_animation_snapshot() -> Dictionary:
	return {"sceneObjectId": PROJECT_ANIMATION_SCENE, "phase": project_animation_phase, "positionSeconds": project_animation_position, "timeSeconds": project_animation_clock, "clipId": project_animation_clip}

func project_animation_execute(command: Dictionary):
	if not project_open or not animation_started or animation_failed or animation_finished:
		return null
	animation_advance(0.0)
	if animation_failed or project_host.failed:
		return null
	var selected := project_animation_range()
	match command["action"]:
		"select":
			project_animation_clip = command["clipId"]
			project_animation_position = 0.0
			project_animation_phase = "paused"
		"play":
			project_animation_completion_sent = false
			if not selected["loop"] and project_animation_position == selected["duration"]:
				project_animation_position = 0.0
			project_animation_phase = "playing"
		"pause": project_animation_phase = "paused"
		"stop":
			project_animation_position = 0.0
			project_animation_phase = "stopped"
		"seek":
			project_animation_position = fmod(float(command["positionSeconds"]), selected["duration"]) if selected["loop"] else float(command["positionSeconds"])
			project_animation_phase = "paused"
		_: return null
	project_animation_sample()
	if animation_failed:
		return null
	project_animation_anchor_clock = project_animation_clock
	project_animation_anchor_position = project_animation_position
	project_animation_anchor_phase = project_animation_phase
	return project_animation_snapshot()
