# Viento animation state script
#@viento-animation-state-script {"format":"viento-animation-state-script","schemaVersion":1,"generator":"godot-gdscript-v1","table":{"initialState":"idle","states":[{"key":"idle"},{"key":"action"}],"transitions":[{"from":"idle","to":"action","trigger":{"kind":"event","name":"physics.landed"}},{"from":"action","to":"idle","trigger":{"kind":"completed"}}]}}
extends Node

# One controller owns the current scene's animation playhead.
# Empty clip parameters select the whole animation. Clip membership is checked
# by the project port, not by this table. Explicit self-edges restart playback.
@export var clip_idle: String = ""
@export var clip_action: String = ""
const _INITIAL_STATE: int = 0
const _EVENT_NAMES: Array = ["physics.landed"]
const _TRANSITIONS: Array = [{"fromIndex":0,"toIndex":1,"trigger":{"kind":"event","name":"physics.landed"}},{"fromIndex":1,"toIndex":0,"trigger":{"kind":"completed"}}]
var _project
var _event_subscriptions: Array = []
var _completion_subscription: int = 0
var _clips: Array = []
var _state: int = -1
var _selected_clip = null
var _active: bool = false

func _port_valid(project) -> bool:
	return typeof(project) == TYPE_OBJECT and is_instance_valid(project)

func _ready() -> void:
	if not has_meta("viento_project"):
		return
	var project = get_meta("viento_project")
	if not _port_valid(project):
		return
	for method in ["subscribe_event", "unsubscribe_event", "subscribe_animation_completed", "unsubscribe_animation_completed", "select_animation_clip", "play_animation"]:
		if not project.has_method(method):
			return
	var clip_pattern := RegEx.new()
	clip_pattern.compile("^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$")
	for value in [clip_idle, clip_action]:
		var matched = clip_pattern.search(value)
		if not value.is_empty() and (matched == null or matched.get_string() != value):
			_clips.clear()
			push_error("Animation state clip parameters require a lowercase UUID or empty text.")
			return
		_clips.append(null if value.is_empty() else value)
	_project = project
	for event_name in _EVENT_NAMES:
		var token = _project.subscribe_event(event_name, _on_event.bind(event_name))
		if typeof(token) != TYPE_INT or token <= 0:
			_deactivate()
			return
		_event_subscriptions.append(token)
	var completion_token = _project.subscribe_animation_completed(_on_completed)
	if typeof(completion_token) != TYPE_INT or completion_token <= 0:
		_deactivate()
		return
	_completion_subscription = completion_token
	_active = true
	_enter_state(_INITIAL_STATE)

func _enter_state(next_state: int) -> bool:
	if not _active or not _port_valid(_project):
		_deactivate()
		return false
	var selection = _clips[next_state]
	if not _project.select_animation_clip(selection):
		_deactivate()
		return false
	if not _project.play_animation():
		# Fail-stop only: a previously accepted select is not rolled back.
		_deactivate()
		return false
	_state = next_state
	_selected_clip = selection
	return true

func _on_event(_value, event_name: String) -> bool:
	if not _active or not _port_valid(_project):
		_deactivate()
		return false
	for edge in _TRANSITIONS:
		if edge["fromIndex"] == _state and edge["trigger"]["kind"] == "event" and edge["trigger"]["name"] == event_name:
			return _enter_state(edge["toIndex"])
	return true

func _on_completed(clip_id) -> bool:
	if not _active or not _port_valid(_project):
		_deactivate()
		return false
	if clip_id != _selected_clip:
		return true
	for edge in _TRANSITIONS:
		if edge["fromIndex"] == _state and edge["trigger"]["kind"] == "completed":
			return _enter_state(edge["toIndex"])
	return true

func _deactivate() -> void:
	var project = _project
	var events = _event_subscriptions
	var completion = _completion_subscription
	_project = null
	_event_subscriptions = []
	_completion_subscription = 0
	_active = false
	_state = -1
	_selected_clip = null
	_clips.clear()
	if not _port_valid(project):
		return
	if project.has_method("unsubscribe_event"):
		for token in events:
			project.unsubscribe_event(token)
	if completion != 0 and project.has_method("unsubscribe_animation_completed"):
		project.unsubscribe_animation_completed(completion)

func _exit_tree() -> void:
	_deactivate()
