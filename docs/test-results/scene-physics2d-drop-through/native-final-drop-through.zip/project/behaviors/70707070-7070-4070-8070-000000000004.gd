extends Node

@export var entered_event: String = "physics.entered"
@export var exited_event: String = "physics.exited"
var _project
var _area: Area2D

func _ready() -> void:
	if not has_meta("viento_project") or not get_parent() is Area2D:
		return
	_project = get_meta("viento_project")
	_area = get_parent() as Area2D
	_area.body_entered.connect(_body_entered)
	_area.body_exited.connect(_body_exited)

func _publish(name: String, body: Node2D) -> void:
	if name.is_empty() or _project == null or not is_instance_valid(body):
		return
	if body.has_meta("viento_instance_id"):
		_project.publish_event(name, String(body.get_meta("viento_instance_id")))

func _body_entered(body: Node2D) -> void:
	_publish(entered_event, body)

func _body_exited(body: Node2D) -> void:
	_publish(exited_event, body)

func _exit_tree() -> void:
	if is_instance_valid(_area):
		if _area.body_entered.is_connected(_body_entered):
			_area.body_entered.disconnect(_body_entered)
		if _area.body_exited.is_connected(_body_exited):
			_area.body_exited.disconnect(_body_exited)
	_project = null
