extends Node
var ticks := -1
func _physics_process(_delta: float) -> void:
	var step: int = get_parent().get_parent().get("physics_observation_step")
	if step == ticks:
		return
	ticks = step
	if ticks == 6:
		Input.action_press("ui_down")
	if ticks == 14:
		Input.action_release("ui_down")
func _exit_tree() -> void:
	Input.action_release("ui_down")
