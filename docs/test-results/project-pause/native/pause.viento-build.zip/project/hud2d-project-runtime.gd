extends "res://camera2d-project-runtime.gd"

const HUD_SCENES = {"c011ec70-2026-4113-8113-000000000030":"res://scenes/c011ec70-2026-4113-8113-000000000030/hud2d.json","c011ec70-2026-4113-8113-000000000031":"res://scenes/c011ec70-2026-4113-8113-000000000031/hud2d.json","c011ec70-2026-4113-8113-000000000032":"res://scenes/c011ec70-2026-4113-8113-000000000032/hud2d.json","c011ec70-2026-4113-8113-000000000033":"res://scenes/c011ec70-2026-4113-8113-000000000033/hud2d.json"}

func enter_scene(scene_id: String) -> void:
	super.enter_scene(scene_id)
	# The complete original actor/physics/behavior factory and author _ready have
	# finished before this visit receives an independent screen-space view.
	if current != null and HUD_SCENES.has(scene_id):
		var overlay = preload("res://hud2d-scene.gd").new()
		overlay.name = "VientoHUD2D"
		overlay.hud_document = HUD_SCENES[scene_id]
		current.add_child(overlay)
