extends "res://project-physics-observation-runtime.gd"

const CAMERA_SCENES = {"c011ec70-2026-4113-8113-000000000031":"scenes/c011ec70-2026-4113-8113-000000000031/camera2d-main.tscn"}

func enter_scene(scene_id: String) -> void:
	# Each PackedScene keeps its original root script and actor paths. Only the
	# selected in-memory member entry gains the independent view adapter node.
	if CAMERA_SCENES.has(scene_id):
		members[scene_id] = CAMERA_SCENES[scene_id]
	super.enter_scene(scene_id)
