extends "res://scenes/c011ec70-2026-4113-8113-000000000032/audio-runtime.gd"

const PROJECT_AUDIO_TRACKS = {"c011ec70-2026-4113-8113-000000000502":"c011ec70-2026-4113-8113-000000000208"}

var project_host
var project_visit := 0
var project_open := true

func _ready() -> void:
	super._ready()
	# The project owns both deterministic smoke steps and live actor/audio time.
	# Author behavior children retain their normal single Godot process callback.
	smoke = true
	set_process(false)

func run_smoke() -> void:
	pass

func project_behavior_port(binding: Dictionary, instance: Node) -> RefCounted:
	return project_host.make_port(project_visit, binding, instance)

func emit(event: String, data: Dictionary = {}) -> void:
	if not project_open or event == "finished":
		return
	if event == "diagnostic":
		behavior_failed = true
		audio_failed = true
	data["protocol"] = 3
	data["event"] = event
	project_host.scene_event(project_visit, "runtime", data)

func audio_emit(event: String, data: Dictionary = {}) -> void:
	if not project_open:
		return
	data["protocol"] = 1
	data["event"] = event
	project_host.scene_event(project_visit, "audio", data)

func project_step(delta: float) -> void:
	if project_open:
		super._process(delta)

func project_close(silent: bool = false) -> void:
	process_mode = Node.PROCESS_MODE_DISABLED
	behavior_finished = true
	if silent:
		project_open = false
	audio_shutdown()
	pass
	project_open = false

# Generated private bridge: author ports receive only a boolean acceptance.
func project_audio_resource(track_id: String) -> String:
	return PROJECT_AUDIO_TRACKS.get(track_id, "")

func project_audio_execute(track_id: String, action: String) -> bool:
	if not project_open or not audio_started or audio_failed or audio_finished or not audio_players.has(track_id):
		return false
	var player = audio_players[track_id]
	if not is_instance_valid(player) or not player is AudioStreamPlayer:
		return false
	if action == "play":
		player.play(0.0)
	elif action == "stop":
		player.stop()
	else:
		return false
	return true

func project_audio_time() -> float:
	return audio_time

func project_animation_declared() -> bool:
	return false

func project_animation_duration() -> float:
	return 0.0

func project_animation_execute(_command: Dictionary):
	return null
