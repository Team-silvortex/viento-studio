extends Node

@export var action_name: String = "ui_accept"
@export var state_values_json: String = '{"score":0,"health":100}'
var _initial_values: Dictionary = {}
var _project
var _active := false
var _armed := false
var _candidate_event_id: int = 0
var _accepted := false
var _window: Window
var _focused := false

func _object_valid(value) -> bool:
	return typeof(value) == TYPE_OBJECT and is_instance_valid(value)

func _ready() -> void:
	_deactivate()
	var values = _parse_initial_values(state_values_json)
	if values == null:
		_fail("Use a strict JSON object with at most 16 bounded scalar defaults and 4096 UTF-8 bytes.")
		return
	_initial_values = values
	if action_name.is_empty():
		_fail("Choose an existing input action.")
		return
	if not has_meta("viento_project_restart"):
		_fail("Bind this script in a project assembly run.")
		return
	var project = get_meta("viento_project_restart")
	if not _object_valid(project) or not project.has_method("request_restart"):
		_fail("The visit-bound scene request port is unavailable.")
		return
	if not InputMap.has_action(action_name):
		_fail("The named input action is not registered; configure the project input map first.")
		return
	_project = project
	_active = true
	_accepted = false
	_window = get_window()
	_focused = _window.has_focus()
	_window.focus_exited.connect(_on_focus_exited)
	_window.focus_entered.connect(_on_focus_entered)
	# Entering a scene while the key is held must not navigate straight through it.
	_armed = _focused and not Input.is_action_pressed(action_name)
	set_process(true)
	set_process_input(true)
	set_process_unhandled_input(true)

func _process(_delta: float) -> void:
	# Observe only. A refused request is never polled or replayed here.
	_candidate_event_id = 0
	if _active:
		_armed = _focused and not Input.is_action_pressed(action_name)

func _input(event: InputEvent) -> void:
	_candidate_event_id = 0
	if not _active or not _focused or _accepted or event.is_echo():
		return
	if event.is_action_released(action_name):
		_armed = not Input.is_action_pressed(action_name)
	elif event.is_action_pressed(action_name, false):
		# Observe before GUI dispatch but do not handle the event or navigate.
		# A GUI-consumed press still consumes its edge, including another mapped
		# key pressed in the same frame before the idle observer can run.
		if _armed:
			_candidate_event_id = event.get_instance_id()
		_armed = false

func _unhandled_input(event: InputEvent) -> void:
	if not _active or not _focused or _accepted or event.is_echo() or event.get_instance_id() != _candidate_event_id:
		return
	_candidate_event_id = 0
	if not event.is_action_pressed(action_name, false):
		return
	if not _object_valid(_project):
		_fail("The visit-bound scene request port is no longer available.")
		return
	var accepted = _project.request_restart(_initial_values)
	if typeof(accepted) != TYPE_BOOL:
		_fail("The scene request port returned an invalid result.")
		return
	if accepted:
		_accepted = true
		_deactivate()
		get_viewport().set_input_as_handled()
	# false is ordinary competition. A fresh release/press may try again; this
	# press, echoes and later idle frames never retry the request automatically.

func _on_focus_exited() -> void:
	_focused = false
	_armed = false
	_candidate_event_id = 0

func _on_focus_entered() -> void:
	_focused = true
	_armed = false
	_candidate_event_id = 0
	# An observed release or a later idle observation of the released action
	# rearms input. Focus changes never replay a previously held key.

func _deactivate() -> void:
	if is_instance_valid(_window):
		if _window.focus_exited.is_connected(_on_focus_exited):
			_window.focus_exited.disconnect(_on_focus_exited)
		if _window.focus_entered.is_connected(_on_focus_entered):
			_window.focus_entered.disconnect(_on_focus_entered)
	_window = null
	_focused = false
	_active = false
	_armed = false
	_candidate_event_id = 0
	_project = null
	set_process(false)
	set_process_input(false)
	set_process_unhandled_input(false)

func _fail(message: String) -> void:
	_deactivate()
	push_error("Level restart: " + message)

func _exit_tree() -> void:
	_deactivate()

func _json_space(text: String, offset: int) -> int:
	while offset < text.length() and text.unicode_at(offset) in [9, 10, 13, 32]:
		offset += 1
	return offset

func _json_hex(text: String, offset: int) -> int:
	if offset + 4 > text.length():
		return -1
	for index in range(offset, offset + 4):
		var code := text.unicode_at(index)
		if not ((code >= 48 and code <= 57) or (code >= 65 and code <= 70) or (code >= 97 and code <= 102)):
			return -1
	return text.substr(offset, 4).hex_to_int()

func _json_string(text: String, offset: int) -> Variant:
	if offset >= text.length() or text.unicode_at(offset) != 34:
		return null
	var start := offset
	offset += 1
	while offset < text.length():
		var code := text.unicode_at(offset)
		if code == 34:
			var parsed := JSON.new()
			if parsed.parse(text.substr(start, offset - start + 1)) != OK or typeof(parsed.data) != TYPE_STRING:
				return null
			return [parsed.data, offset + 1]
		if code < 32 or (code >= 0xd800 and code <= 0xdfff):
			return null
		if code != 92:
			offset += 1
			continue
		if offset + 1 >= text.length():
			return null
		var escape := text.unicode_at(offset + 1)
		if escape in [34, 92, 47, 98, 102, 110, 114, 116]:
			offset += 2
			continue
		if escape != 117:
			return null
		var escaped := _json_hex(text, offset + 2)
		if escaped < 0 or (escaped >= 0xdc00 and escaped <= 0xdfff):
			return null
		if escaped >= 0xd800 and escaped <= 0xdbff:
			if offset + 12 > text.length() or text.unicode_at(offset + 6) != 92 or text.unicode_at(offset + 7) != 117:
				return null
			var low := _json_hex(text, offset + 8)
			if low < 0xdc00 or low > 0xdfff:
				return null
			offset += 12
		else:
			offset += 6
	return null

func _initial_key_valid(key: String) -> bool:
	var pattern := RegEx.new()
	pattern.compile("^[A-Za-z][A-Za-z0-9_.-]{0,63}$")
	var matched = pattern.search(key)
	return key.length() <= 64 and not key in ["constructor", "prototype", "__proto__"] and matched != null and matched.get_string() == key

func _parse_initial_values(text: String) -> Variant:
	if text.to_utf8_buffer().size() > 4096:
		return null
	var offset := _json_space(text, 0)
	if offset >= text.length() or text.unicode_at(offset) != 123:
		return null
	offset = _json_space(text, offset + 1)
	var values: Dictionary = {}
	if offset < text.length() and text.unicode_at(offset) == 125:
		return values if _json_space(text, offset + 1) == text.length() else null
	var numbers := RegEx.new()
	numbers.compile("^-?(?:0|[1-9][0-9]*)(?:\\.[0-9]+)?(?:[eE][+-]?[0-9]+)?")
	while offset < text.length():
		var key = _json_string(text, offset)
		if key == null or not _initial_key_valid(key[0]) or values.has(key[0]) or values.size() >= 16:
			return null
		offset = _json_space(text, key[1])
		if offset >= text.length() or text.unicode_at(offset) != 58:
			return null
		offset = _json_space(text, offset + 1)
		if offset >= text.length():
			return null
		var value
		if text.unicode_at(offset) == 34:
			var token = _json_string(text, offset)
			if token == null:
				return null
			value = token[0]
			offset = token[1]
		elif text.substr(offset, 4) == "true":
			value = true
			offset += 4
		elif text.substr(offset, 5) == "false":
			value = false
			offset += 5
		else:
			var matched = numbers.search(text.substr(offset))
			if matched == null:
				return null
			var number := JSON.new()
			if number.parse(matched.get_string()) != OK:
				return null
			value = number.data
			if not (typeof(value) in [TYPE_INT, TYPE_FLOAT]) or not is_finite(float(value)) or abs(float(value)) > 1000000000.0:
				return null
			offset += matched.get_string().length()
		values[key[0]] = value
		offset = _json_space(text, offset)
		if offset >= text.length():
			return null
		if text.unicode_at(offset) == 125:
			return values if _json_space(text, offset + 1) == text.length() else null
		if text.unicode_at(offset) != 44:
			return null
		offset = _json_space(text, offset + 1)
	return null
