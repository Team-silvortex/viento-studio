extends Node
var ticks := -1
var control
var scene
func _ready() -> void:
	scene = get_parent().get_parent()
	control = get_meta("viento_platform_control")
	assert(control.protocol_version() == 1)
	assert(control.read_running() == true)
	var endpoints = get_meta("viento_platform_events")
	endpoints.origin_reached.connect(endpoint.bind("origin"))
	endpoints.destination_reached.connect(endpoint.bind("destination"))
	assert(control.request_running(false))
func endpoint(name: String) -> void:
	print("CONTROL_ENDPOINT:" + JSON.stringify({"name":name,"step":scene.physics_observation_step,"platform":"79797979-7979-4979-8979-000000000001"}))
func _physics_process(_delta: float) -> void:
	var tick: int = scene.physics_observation_step
	if ticks == tick:
		return
	ticks = tick
	if ticks == 8:
		assert(control.request_running(true))
	var rows := []
	for actor in scene.actors:
		if actor["instanceId"] in ["bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbb1","79797979-7979-4979-8979-000000000003","79797979-7979-4979-8979-000000000001","83838383-8383-4838-8838-000000000001"]:
			rows.append({"id":actor["instanceId"],"position":[actor["node"].position.x,actor["node"].position.y],"grounded":scene.character_motion_grounded.get(actor["instanceId"],false) if scene.get("character_motion_grounded") is Dictionary else false})
	print("CONTROL_PROBE:" + JSON.stringify({"step":ticks,"visit":scene.project_visit,"actors":rows,"phase":scene.platform_motion.platforms["79797979-7979-4979-8979-000000000001"]["phase"],"running":control.read_running(),"platform":"79797979-7979-4979-8979-000000000001"}))
