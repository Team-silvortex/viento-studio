extends Node
var ticks := -1
func _ready() -> void:
	pass
func _physics_process(_delta: float) -> void:
	var step: int = get_parent().get_parent().get("physics_observation_step")
	if step == ticks:
		return
	ticks = step
	if ticks == 6:
		Input.action_press("ui_accept")
	if ticks == 7 or ticks == 11:
		Input.action_release("ui_accept")
func _exit_tree() -> void:
	Input.action_release("ui_accept")

