extends Node
var ticks := -1
func _ready() -> void:
	Input.action_press("ui_right")
func _physics_process(_delta: float) -> void:
	var step: int = get_parent().get_parent().get("physics_observation_step")
	if step == ticks:
		return
	ticks = step
	Input.action_release("ui_right")
	Input.action_release("ui_left")
	if ticks < 9 or ticks >= 17:
		Input.action_press("ui_right")
	elif ticks >= 11 and ticks < 14:
		Input.action_press("ui_left")
func _exit_tree() -> void:
	Input.action_release("ui_right")
	Input.action_release("ui_left")
